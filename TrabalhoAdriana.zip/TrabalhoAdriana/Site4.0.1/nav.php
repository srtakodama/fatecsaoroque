<nav id='topo' class='navbar navbar-inverse navbar-default' role='navigation'>
    <div class='container-fluid'>
        
        <div class='navbar-header'>
            <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1'>
                <span class='sr-only'>Toggle navigation</span>
                <span class='icon-bar'></span>
                <span class='icon-bar'></span>
                <span class='icon-bar'></span>
            </button>
            <a class='navbar-brand' href='index.php'>Home</a>
        </div>
        
        <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>
            <ul class='nav navbar-nav'></ul>
            <ul class='nav navbar-nav navbar-right'>
                
                <li><a href='curiosidades.php'>Curiosidades</a>
                </li>
                <li><a href='quiz.php.'>Quiz</a>
                </li>
                <li><a href='quemsomos.php'>Quem Somos</a>
                </li>
                <li><a href='contato.php'>Contato</a>
                    
                </li>
            </ul>
        </div>
       
    </div>
   
</nav>

<!-- Aumentar e Diminuir Texto!........................................................................................................... -->   
        <button type="button" onclick="" class="inc-font btn" title="Aumentar fonte"><span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span> A+</button>
        <button type="button" onclick="" class="res-font btn" title="Tamanho normal da fonte"><span class="glyphicon glyphicon-off" aria-hidden="true"></span> Limpar</button>
        <button type="button" onclick="" class="dec-font btn" title="Diminuir fonte"><span class="glyphicon glyphicon-zoom-out" aria-hidden="true"></span> A-</button>
<!-- Fim!........................................................................................................... -->    