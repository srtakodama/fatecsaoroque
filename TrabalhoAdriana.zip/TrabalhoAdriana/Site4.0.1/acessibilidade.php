<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
    <div class="container"> <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acessibilidade</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<!--Aqui começa o Header-->
    <?php
    include"header.php";
    ?>
<!--Aqui termina o Header-->
    
<!--Aqui começa o Nav-->
    <?php
    include"nav.php";    
    ?>
<!--Aqui termina o Nav-->
<body data-spy="scroll" data-target=".teste">
    <br class="hidden-xs">
    <br class="hidden-xs">
    <article class="col-lg-12 col-xs-12 col-sm-12tab-content container">
        <div id="mata" class="divmargin">

            <div class="hidden-xs">
                <img src="imagens/acessibilidade.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                
                <h2 class="titulo">Formas de tornar seu conteúdo acessível</h2>
            
                
                <p class="text-justify">Cada dia mais as formas de se tornar o acesso à informações e serviços que são disponibilizados através da internet  são aperfeiçoadas para serem utilizadas pelos usuários com necessidades especiais, as ferramentas são diversas e cada vez mais pessoas se beneficiam delas e descobrem o mundo através da internet.</p>
                <p class="text-justify">Mas não são só as ferramentas e softwares que vêm para tornar o acesso mais prático e rápido ao conteúdo, também são utilizados padrões que tornam a navegação do usuário pela página mais agradável.</p>
                <p class="text-justify">As páginas devem ter um conteúdo disposto com letras de fácil compreensão, cores com constraste correto, botões e links que ajudem o usuário a se localizar na página. Além desses recursos que são colocados na página no momento de sua "construção" são utilizadas também as ferramentas, por exemplo, os leitores de tela, teclados especiais, entre outros.</p>
                
            </div>
             <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <img src="imagens/acessibilidade.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                
                <h2 class="titulo">Formas de tornar seu conteúdo acessível</h2>
            
                
                <p class="text-justify">Cada dia mais as formas de se tornar o acesso à informações e serviços que são disponibilizados através da internet  são aperfeiçoadas para serem utilizadas pelos usuários com necessidades especiais, as ferramentas são diversas e cada vez mais pessoas se beneficiam ...
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal">Ver Mais...</a>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Formas de tornar o conteúdo acessível</h4>
                                </div>
                                <div class="modal-body">
 
                                    <p class="text-justify">Cada dia mais as formas de se tornar o acesso à informação são aperfeiçoadas e utilizadas na web, as ferramentas são doversas e cada vez mais pessoas se beneficiam delas e descobrem o mundo através da internet</p>
                <p class="text-justify">Hoje em dia as formas de se tornar o conteúdo disponibilizado através de sites na web mais acessíveis são várias.Abaixo listamos algumas ferramentas.</p>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <div id="estacao" class="divmargin">

            <div class="hidden-xs">
                <img src="imagens/acessibilidade2.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="A foto mostra duas mãos estendidas e estão segurando letras, no caso 3 w, formando o www do acesso a internet"/>
                <h2 class="titulo">Por que é importante ser acessível?</h2>
                <p class="text-justify">A falta de tempo, de disponibilidade das pessoas está fazendo com que cada dia mais aumente o número das que escolhem realizar tarefas simples do seu dia através do uso da internet, isso facilita e agiliza o processo.</p>
                <p class="text-justify">E com as pessoas que possuem deficiência não é diferente, elas também querem otimizar o seu tempo e realizar mais rápido tarefas do dia-a-dia.</p>
                
                
                    <p class="text-justify">Com isso ser acessível hoje em dia mais do que uma "obrigação" se tornou sinônimo de sucesso, pois se o seu site exclui os portadores de deficiência, que ao acessá-lo encontram um ambiente de difícil entendimento e pouco usual, com certeza encontrarão outro site que tenha os requisitos necessários para que ele possa com conforto e rapidez navegar e de forma rápida, que disponibilize a ele as ferramentas necessárias para tornar essa navegação a melhor possível, fazendo que com utilize esse site mais vezes, pois tanto o seu conteúdo quanto as suas ferramentas são adequadas também para quem têm necessidades especiais. </p>
            </div>
            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <img src="imagens/acessibilidade2.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="A foto mostra duas mãos estendidas e estão segurando letras, no caso 3 w, formando o www do acesso a internet"/>
                <h2 class="titulo">Por que é importante ser acessível?</h2>
                <p class="text-justify">A falta de tempo, de disponibilidade das pessoas está fazendo com que cada dia mais aumente o número das que escolhem realizar tarefas simples do seu dia através do uso da internet...
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal2">Ver Mais...</a>
                    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Por que é importante ser acessível?</h4>
                                </div>
                                <div class="modal-body">

                                    <p class="text-justify">A falta de tempo, de disponibilidade das pessoas está fazendo com que cada dia mais aumente o número das que escolhem realizar tarefas simples do seu dia através do uso da internet, isso facilita e agiliza o processo.</p>
                <p class="text-justify">E com as pessoas que possuem deficiência não é diferente, elas também querem otimizar o seu tempo e realizar mais rápido tarefas do dia-a-dia.</p>
                
                
                    <p class="text-justify">Com isso ser acessível hoje em dia mais do que uma "obrigação" se tornou sinônimo de sucesso, pois se o seu site exclui os portadores de deficiência, que ao acessá-lo encontram um ambiente de difícil entendimento e pouco usual, com certeza encontrarão outro site que tenha os requisitos necessários para que ele possa com conforto e rapidez navegar e de forma rápida, que disponibilize a ele as ferramentas necessárias para tornar essa navegação a melhor possível, fazendo que com utilize esse site mais vezes, pois tanto o seu conteúdo quanto as suas ferramentas são adequadas também para quem têm necessidades especiais. </p>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        
        <div id="mata" class="divmargin">

            <div class="hidden-xs">
                <img src="imagens/acessibilidade3.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                
                <h2 class="titulo">Inovação para pessoas com deficiência</h2>
                
                
                
                <p class="text-justify">A tecnologia é de grande auxílio na invenção e implementação de novas formas de facilitar o acesso à web para pessoas que possuam algum tipo de deficiência. Se para as pessoas que não têm nenhuma dificuldade para se locomover ou enxergar por exemplo a internet se tornou algo útil e muitas vezes indispensável na hora de buscar informações ou fazer algo de maneira rápida e prática, para os portadores de deficiência se tornou essencial. E em um mundo onde a internet é utilizada para praticamente tudo, quem não tem esse acesso só tem a perder.</p>
                <p class="text-justify">Claro que tantos os portadores de deficiência quanto as pessoa que não a possuem conseguem "se virar" sem ela, mas se há a internet existe e têm muitos benefícios para quem usa, não é justo que uma condição fisíca seja o motivo de impedimento para esse acesso, por isso, as ferramentas que são criadas e aprimoradas com a ajuda da tecnologia são muito bem vindas.</p>
                <p class="text-justify">As ferramentas e softwares que temos hoje trazem a possibilidade de pessoas com deficiência motora, visual, auditiva entre outras terem a experiência do acesso e navegação na internet sem precisar do auxílio de terceiros para isso. Com isso os portadores de necessidades especiais ganham independência e maior conforto e praticidade para acessar o conteúdo e o serviço de sua preferência e necessidade.</p>
            </div>

            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <img src="imagens/acessibilidade3.jpg" class="col-lg-2 col-md-3 col-sm-4 col-xs-12" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                
                <h2 class="titulo">Inovação para pessoas com deficiência</h2>
                
                
                
                <p class="text-justify">A tecnologia é de grande auxílio na invenção e implementação de novas formas de facilitar o acesso à web para pessoas que possuam algum tipo de deficiência...
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal">Ver Mais...</a>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Inovação para pessoas com deficiência</h4>
                                </div>
                                <div class="modal-body">
 
                                    <p class="text-justify">A tecnologia é de grande auxílio na invenção e implementação de novas formas de facilitar o acesso à web para pessoas que possuam algum tipo de deficiência.</p>
                <p class="text-justify">As ferramentas e softwares que temos hoje trazem a possibilidade de pessoas com deficiência motora, visual, auditiva entre outras terem a experiência do acesso e navegação na internet sem precisar do auxílio de terceiros para isso. Com isso os portadores de necessidades especiais ganham independência e maior conforto e praticidade para acessar o conteúdo e o serviço de sua preferência e necessidade.</p>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <div class="col-xs-12 divmargin">
            <a href="#topo">
                <br>
                <center>Voltar para o Topo</center>
            </a>
        </div>
    </article>
    <!--Aqui começa o Footer-->
        <?php
        include"footer.php";
        ?>
    <!--Aqui termina o Footer-->
</body>
    </div>
</html>