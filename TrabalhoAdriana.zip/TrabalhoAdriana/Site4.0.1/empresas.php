<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
    <div class="container"> <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>:: TKS - O Português agradece!!! ::</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<!--Aqui começa o Header-->
    <?php
    include"header.php";
    ?>
<!--Aqui termina o Header-->
    
<!--Aqui começa o Nav-->
    <?php
    include"nav.php";    
    ?>
<!--Aqui termina o Nav-->
<body data-spy="scroll" data-target=".teste">
    <br class="hidden-xs">
    <br class="hidden-xs">
    <article class="col-lg-12 col-xs-12 col-sm-12tab-content container">
    <h1 class="titulo">Quiz da Língua Portuguesa</h1>
    
    
    
    <div id="hvinho" class="divmargin">
      
              
          <div class="">
                  <div title="modal" class="">
 <!--  aparece no desktop -->   
           <div class="hidden-xs">
                <!-- Aqui começa a codificação do JavaScript -->
            <script language="JavaScript"> 
                /* início do código */ 
                <!-- 
                var pontos=0; 
                function reponse(form) { 
                    for (var i=0;i<form.length;i++){ 
                    if (form[i].checked){ 
                        break 
                        } 
                    } 
                    var answer="" 
                    if (i<form.length){ 
                        answer = form[i].value 
                        } 
                        return answer; 
                    } 

                function solution(form) { 
                /* variável para cada pergunta */ 
                    var points=0;var rep="";var comment="";var resposta1="";var resposta2="";var resposta3=""; var resposta4=""; var resposta5=""; var resposta6=""; var resposta7=""; var resposta8=""; var resposta9=""; var resposta10=""; var onome="" 

                /* valor de pontos para as questões */ 
                    if (reponse(form.question1)=="C") {pontos+=1} 
                    if (reponse(form.question2)=="A") {pontos+=1} 
                    if (reponse(form.question3)=="B") {pontos+=1}
                    if (reponse(form.question4)=="C") {pontos+=1}
                    if (reponse(form.question5)=="C") {pontos+=1}
                    if (reponse(form.question6)=="A") {pontos+=1}
                    if (reponse(form.question7)=="A") {pontos+=1}
                    if (reponse(form.question8)=="B") {pontos+=1}
                    if (reponse(form.question9)=="B") {pontos+=1}
                    if (reponse(form.question10)=="C") {pontos+=1}

                /* cada mensagem vai de acordo com o input marcado para resposta */ 

                /* mensagem para questão 1 */ 
                    if (reponse(form.question1)=="") {resposta1="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question1)=="A") {resposta1="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question1)=="B") {resposta1="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question1)=="C") {resposta1="<font color=#0099cc>correta</font>"} 

                /* mensagem para questão 2 */ 
                    if (reponse(form.question2)=="") {resposta2="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question2)=="A") {resposta2="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question2)=="B") {resposta2="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question2)=="C") {resposta2="<font color=#cccccc>incorreta</font>"} 

                    /* mensagem para questão 3 */ 
                    if (reponse(form.question3)=="") {resposta3="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question3)=="A") {resposta3="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question3)=="B") {resposta3="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question3)=="C") {resposta3="<font color=#cccccc>incorreta</font>"}
                    
                     /* mensagem para questão 4 */ 
                    if (reponse(form.question4)=="") {resposta4="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question4)=="A") {resposta4="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question4)=="B") {resposta4="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question4)=="C") {resposta4="<font color=#0099cc>correta</font>"}
                    
                     /* mensagem para questão 5 */ 
                    if (reponse(form.question5)=="") {resposta5="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question5)=="A") {resposta5="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question5)=="B") {resposta5="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question5)=="C") {resposta5="<font color=#0099cc>correta</font>"}
                    
                     /* mensagem para questão 6 */ 
                    if (reponse(form.question6)=="") {resposta6="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question6)=="A") {resposta6="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question6)=="B") {resposta6="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question6)=="C") {resposta6="<font color=#cccccc>incorreta</font>"}
                    
                     /* mensagem para questão 7 */ 
                    if (reponse(form.question7)=="") {resposta7="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question7)=="A") {resposta7="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question7)=="B") {resposta7="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question7)=="C") {resposta7="<font color=#cccccc>incorreta</font>"}
                    
                     /* mensagem para questão 8 */ 
                    if (reponse(form.question8)=="") {resposta8="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question8)=="A") {resposta8="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question8)=="B") {resposta8="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question8)=="C") {resposta8="<font color=#cccccc>incorreta</font>"}
                    
                     /* mensagem para questão 9 */ 
                    if (reponse(form.question9)=="") {resposta9="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question9)=="A") {resposta9="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question9)=="B") {resposta9="<font color=#0099cc>correta</font>"} 
                    if (reponse(form.question9)=="C") {resposta9="<font color=#cccccc>incorreta</font>"}
                    
                     /* mensagem para questão 10 */ 
                    if (reponse(form.question10)=="") {resposta10="<font color=#cccccc>não respondida</font>"} 
                    if (reponse(form.question10)=="A") {resposta10="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question10)=="B") {resposta10="<font color=#cccccc>incorreta</font>"} 
                    if (reponse(form.question10)=="C") {resposta10="<font color=#0099cc>correta</font>"}

                    /* aqui é exibido a mensagem de acordo com o ponto marcado */ 
                    if (pontos==0) {comment="você não fez pontos, tente novamente!"}
                    if (pontos==1) {comment="você fez 01 ponto, precisa melhorar!"}
                    if (pontos==2) {comment="você fez 02 pontos, precisa melhorar mais!"}
                    if (pontos==3) {comment="você fez 03 pontos, ainda está ruim!"}
                    if (pontos==4) {comment="você fez 04 pontos, está um pouco melhor, treine mais!"}
                    if (pontos==5) {comment="você fez 05 pontos, nada mal, mas pode melhorar mais!"}
                    if (pontos==6) {comment="você fez 06 pontos, mais da metade, dá pra praticar mais um pouquinho!"}
                    if (pontos==7) {comment="você fez 07 pontos, está vendo, que avanço!"}
                    if (pontos==8) {comment="você fez 08 pontos, nível bom!"} 
                    if (pontos==9) {comment="você fez 09 pontos, nível ótimo!"} 
                    if (pontos==10) {comment="Nível excelente! você acertou todas!<br><br><a href=\"javascript:;\" onClick=\"window.print();return false\">Imprimir este certificado</a><br>Veja o seu certificado abaixo:<br><br><img src=img_certificado.jpg border=0>"} 

                    /* aqui exibo a porcentagem de acordo com o ponto */ 
                    if (pontos==0) {porcentagem="0%"}
                    if (pontos==1) {porcentagem="10%"}
                    if (pontos==2) {porcentagem="20%"}
                    if (pontos==3) {porcentagem="30%"}
                    if (pontos==4) {porcentagem="40%"}
                    if (pontos==5) {porcentagem="50%"}
                    if (pontos==6) {porcentagem="60%"}
                    if (pontos==7) {porcentagem="70%"}
                    if (pontos==8) {porcentagem="80%"} 
                    if (pontos==9) {porcentagem="90%"} 
                    if (pontos==10) {porcentagem="100%"} 

                    /* aqui inicio o código mostrado na nova janela */ 
                    chaine='' 
                    +'<head><title>Resultado</title>' 
                    +'<style type=text/css>a{font-family:arial;font-size:8pt;color:#696969;text-decoration:none;}#texto{font-family:verdana,arial;font-size:8pt;color:#696969;}#textos{font-family:verdana,arial;font-size:10px;color:#c7c7c7;}input{border:1px solid #f8f8f8;background-color:fefefe;font-family:arial;font-size:8pt;color:#1c1c1c;}#resultado{font-family:arial;font-size:8pt;color:#696969;}</style>' 
                    +'</head>' 
                    +'<center><font id=texto>Você atingiu um total de <font color=#0099cc><b>'+ pontos +'</b></font> pontos, acertando '+ porcentagem +' das questões.<br><br><font color=#696969>'+comment+'<br>' 

                    +'<br><center><font id=texto>'+ formmail.onome.value +' veja abaixo o resumo das questões:</font></center><br>' 

                    +'<table border=0 cellpading=3 cellspacing=3 style="border:1px solid #f8f8f8;background-color:#ffffff;" width="150">' 
                    +"<tr><td><font id=textos>1)</td><td><font id=resultado>"+ resposta1 +"</font></td></tr>" 
                    +"<tr><td><font id=textos>2)</td><td><font id=resultado>"+ resposta2 +"</font></td></tr>" 
                    +"<tr><td><font id=textos>3)</td><td><font id=resultado>"+ resposta3 +"</font></td></tr>"
                    +"<tr><td><font id=textos>4)</td><td><font id=resultado>"+ resposta4 +"</font></td></tr>"
                    +"<tr><td><font id=textos>5)</td><td><font id=resultado>"+ resposta5 +"</font></td></tr>"
                    +"<tr><td><font id=textos>6)</td><td><font id=resultado>"+ resposta6 +"</font></td></tr>"
                    +"<tr><td><font id=textos>7)</td><td><font id=resultado>"+ resposta7 +"</font></td></tr>"
                    +"<tr><td><font id=textos>8)</td><td><font id=resultado>"+ resposta8 +"</font></td></tr>"
                    +"<tr><td><font id=textos>9)</td><td><font id=resultado>"+ resposta9 +"</font></td></tr>"
                    +"<tr><td><font id=textos>10)</td><td><font id=resultado>"+ resposta10 +"</font></td></tr>"
                    +"</table></form>" 
                    +'<a href="javascript:void(0)" onclick="javascript:window.close()" style="border:2px solid #ff0000;background-color:#ffffff;color:#696969;">FECHAR</a>' 
                    +'</CENTER></BODY></HTML>' 
                    solu=open(); 
                    solu.document.write(chaine) 
                } 
                //--> 
            </script>
    </head>
    <body class="fundo">
        <script> 
            function vai() { 
                location.reload() 
            } 
        </script> 

        <!--ABAIXO SEGUE O QUIZ--> 
        <div align="center"> 
            <p id="center">Responda ao QUIZ de Perguntas e Respostas abaixo:</p> 
            <p id="normal">Lembrando que cada questão vale 1 ponto.</p> 
            <p id="normal">[ marque somente uma questão por pergunta ]</p>
            </div>
            <div align="center"> 
                <table border="0" cellpading="3" cellspacing="3" style="border:1px solid #f8f8f8;background-color:#ffffff;" width="600"> 
                    <tr>
                        <td> 
                            <p id="pergunta"> 
                                Coloque ao lado o seu Nome:&nbsp;
                            </p>
                            <input type="text" name="onome" value="" size="44" id="input"><font color="#0099cc" face="verdana" size="2"><strong>&nbsp;*</strong> 
                            <p id="pergunta"> 
                                1 - Qual das expressões abaixo está correta?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question1" value="A">&nbsp;Fazem dez dias que não o vejo.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question1" value="B">&nbsp;Houveram muitos problemas após minhas férias.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question1" value="C">&nbsp;Faz dois meses que estamos namorando.</p> 
                            <p id="pergunta"> <br/>
                                2 - De acordo com o advérbio "MENOS", é correto afirmar:
                            </p> 
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question2" value="A">&nbsp;O advérbio é invariável, ou seja, não admite a forma feminina Menas.</p> 
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question2" value="B">&nbsp;O advérbio é variável, ou seja, ele possui a forma feminina Menas.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question2" value="C">&nbsp;A expressão: "Comi menas comida." está correta.</p> 
                            <p id=pergunta><br/>
                                3 - Indique a expressão que está grafada corretamente?
                            </p> 
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question3" value="A">&nbsp;A garota disse: <u>Muito Obrigado</u> pelo presente.</p> 
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question3" value="B">&nbsp;Os alunos em coro disseram: <u>Muito obrigados</u>!</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question3" value="C">&nbsp;<u>Muito obrigada</u>, disse o aluno ao professor de Inglês.</p>
                            <p id="pergunta"><br/>
                                4 - Qual alternativa é a mais adequada?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question4" value="A">&nbsp;Já são dez horas da manhã, acorda!.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question4" value="B">&nbsp;É meio dia e quarenta e cinco minutos, logo o almoço estará na mesa.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question4" value="C">&nbsp;As duas alternativas acima estão corretas.</p>
                            <p id="pergunta"><br/> 
                                5 - Qual o grupo de palavras que está com a grafia correta?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question5" value="A">&nbsp;Pagem, miragem, reciclagem, vertigem.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question5" value="B">&nbsp;beringela, tigreza, tijela, jiboia, jenipapo</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question5" value="C">&nbsp;jenipapo, berinjela, tigela, vertigem</p>
                            <p id="pergunta"><br/> 
                                6 - Considerando que antônimo é palavra contrária a outra, qual alternativa contém antônimos?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question6" value="A">&nbsp;Pudico - extrovertido, Prudente - insolente</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question6" value="B">&nbsp;Supérfluo - excessivo, Contingente - infrequente</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question6" value="C">&nbsp;Leviano - inconstante, Pretensioso - imodesto</p>
                            <p id="pergunta"><br/>
                                7 - Quanto à forma de uso dos pronomes, escolha a opção que se julga correta:
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question7" value="A">&nbsp;Ele emprestará seu livro para eu ler nas férias.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question7" value="B">&nbsp;Para mim estudar, disse a garota ansiosa.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question7" value="C">&nbsp;Empresta este livro pra eu?.</p>
                            <p id="pergunta"><br/> 
                                8 - Quanto ao uso da Crase, qual a alternativa melhor corresponde a sua regra?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question8" value="A">&nbsp;Nós ficamos cara à cara.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question8" value="B">&nbsp;Cortou cabelo à Cauby Peixoto.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question8" value="C">&nbsp;Escolhi à dedo meu par pra valsa.</p>
                            <p id="pergunta"><br/> 
                                9 - Qual é a opção mais adequada?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question9" value="A">&nbsp;O termômetro marcou zero graus.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question9" value="B">&nbsp;Sua féria crescia muito no verão.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question9" value="C">&nbsp;Estava com dor na costa.</p>
                            <p id="pergunta"><br/> 
                                10 - A palavra composta surdo-mudo causa bastante confusão, qual é a forma correta?
                            </p>  
                            <p id="pergunta">(A)&nbsp;<input type="radio" name="question10" value="A">&nbsp;Crianças surdas-muda é pelo menos 20% no Brasil.</p>
                            <p id="pergunta">(B)&nbsp;<input type="radio" name="question10" value="B">&nbsp;Os dois eram surdo-mudos.</p> 
                            <p id="pergunta">(C)&nbsp;<input type="radio" name="question10" value="C">&nbsp;O filme era sobre uma surda-muda.</p>    
                            <input type="button" name="valide" value="Veja seu resultado aqui" onclick="javascript:solution(this.form);" style="border:2px solid #ff0000;background-color:#ffffff;color:#696969;"> 
                        </td>
                    </tr> 
                </table> 
                <a href=# onClick="vai()"><p id="normal">[ Clique aqui para fazer Novamente ]</p></a>
                <p>Adaptado by: &copy; Thelma Kodama - Meu Blog: <a href="http://www.srtakodama.com" target="_blank" >srtakodama.com</a></p>

                      </div>
 <!--  fim do que aparece no desktop -->              
                      
<!--  aparece no mobile -->                    
        <div class="text-justify hidden-sm hidden-md hidden-lg"><p class="text-justify">O computador e a Internet representam um enorme passo para a inclusão de pessoas com deficiência, promovendo autonomia e independência. Mas como pessoas com deficiência utilizam o computador?</p>
               <p class="text-justify">A inclusão social das pessoas com deficiência deve ser um dos objetivos nas sociedades que defendem os valores da solidariedade e da integração, além do respeito pelas diferenças pessoais. A acessibilidade exerce papel fundamental nessa inclusão...
          <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal"
          data-target="#myModal">Ver Mais...</a></div>
<!--  fim do que aparece no mobile --> 

          <div class="modal fade" id="myModal" tabindex="-1"
          role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span class="sr-only">Close</span>
                  </button>
                  <h4 class="modal-title titulo" id="myModalLabel">O acesso de pessoas com deficiência</h4>
                </div>
                <div class="modal-body">
                  
               <p class="text-justify">A inclusão social das pessoas com deficiência deve ser um dos objetivos nas sociedades que defendem os valores da solidariedade e da integração, além do respeito pelas diferenças pessoais. A acessibilidade exerce papel fundamental nessa inclusão. A empresa deverá conscientizar todos os seus empregados, mediante treinamentos e execução de ações para eliminar barreiras e promover a acessibilidade. A empresa pode melhorar, por exemplo, o acesso ao local de trabalho por pessoas com diferentes tipos de deficiência, incluindo facilidades para entrar e se movimentar no estabelecimento, além de acesso a banheiros e lavatórios. O planejamento para emergências deve assegurar que pessoas com deficiência possam deixar, com segurança e eficiência, o local de trabalho e se deslocar para uma área segura.</p>
               <p class="text-justify">O acesso à informação também é fundamental, devendo ser disponibilizados na empresa, por exemplo, manuais e instruções relativas ao posto de trabalho de forma a serem compreendidos por pessoas com diferentes tipos de deficiência.</p>
               <p class="text-justify">A Lei nº 10.098, de 19 de dezembro de 2000, estabelece normas gerais e critérios básicos para a promoção da acessibilidade das pessoas portadoras de deficiência ou com mobilidade reduzida, mediante a supressão de barreiras e de obstáculos nas vias e espaços públicos, no mobiliário urbano, na construção e reforma de edifícios e nos meios de transporte e de comunicação. Para fins dessa Lei são estabelecidas as seguintes definições:</p>
               <p class="text-justify">Acessibilidade: possibilidade e condição de alcance para utilização, com segurança e autonomia, dos espaços, mobiliários e equipamentos urbanos, das edificações, dos transportes e dos sistemas e meios de comunicação, por pessoa portadora de deficiência ou com mobilidade reduzida;</p>
               <p class="text-justify">Barreiras: qualquer entrave ou obstáculo que limite ou impeça o acesso, a liberdade de movimento e a circulação com segurança das pessoas, classificadas em: 
a.	barreiras arquitetônicas urbanísticas: as existentes nas vias públicas e nos espaços de uso público;
b.	barreiras arquitetônicas na edificação: as existentes no interior dos edifícios públicos e privados;
c.	barreiras arquitetônicas nos transportes: as existentes nos meios de transporte;
d.	barreiras nas comunicações: qualquer entrave ou obstáculo que dificulte ou impossibilite a expressão ou o recebimento de mensagens por intermédio dos meios ou sistemas de comunicação, sejam ou não de massa.
</p>

        <a href="http://emag.governoeletronico.gov.br"><li>Saiba mais</li></a>
                </div>
                <!--
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>

                </div>
                -->
            </div>

          </div>
        </div>          
          </div> 
</div>
    
    
    
    <div id="pvinho"class="divmargin">
        
        <h2 class="titulo"></h2>
        <p class="text-justify"></p>
       
</div>
    
    <div id="fases">
        
        



                 <div id="fases">
                  <div title="modal" class="">
          <h2 class="titulo"></h2>
 <!--  aparece no desktop -->   
           <div class="hidden-xs">

       
          </div>
 <!--  fim do que aparece no desktop -->              
                      
<!--  aparece no mobile -->                    
        <div class="text-justify hidden-sm hidden-md hidden-lg">
          <p> Para visualizar o Quiz da Língua Portuguesa, acesse de um computador desktop ou notebook, melhor resolução 800x600. </p>
                </div>
              </div>
            </div>
          </div>
        </div>          
          </div>
        
        
        </div>
         <div class="col-xs-12 divmargin"><a href="#topo"><br><center>Voltar para o Topo</center></a></div>
    </article>
    <!--Aqui começa o Footer-->
        <?php
        include"footer.php";
        ?>
    <!--Aqui termina o Footer-->
</body>
    </div>
</html>