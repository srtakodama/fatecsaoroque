<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<div class="container">
    <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Acessibilidade</title>
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/estilo.css" rel="stylesheet" />
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <!--Aqui começa o Header-->
    <?php include "header.php"; ?>
    <!--Aqui termina o Header-->

    <!--Aqui começa o Nav-->
    <?php include "nav.php"; ?>
    <!--Aqui termina o Nav-->

    <body data-spy="scroll" data-target=".teste">
        <br class="hidden-xs">
        <br class="hidden-xs">
        <article class="col-lg-12 col-xs-12 col-sm-12tab-content container">
    <h1 class="titulo">Implementação nos  dispositivos.</h1>
    
    
    
    <div id="hvinho" class="divmargin">
      
                <img class="img-responsive img-thumbnail imagemfloat" src="imagens/modelo-brasileiro-de-acessibilidade.jpg"
        alt="Produção de Vinho">
          <div class="">
                  <div title="modal" class="">
          <h2 class="titulo">O acesso de pessoas com deficiência</h2>
 <!--  aparece no desktop -->   
           <div class="hidden-xs">
               <p class="text-justify">O computador e a Internet representam um enorme passo para a inclusão de pessoas com deficiência, promovendo autonomia e independência. Mas como pessoas com deficiência utilizam o computador?</p>
               <p class="text-justify">No que se refere a acesso ao computador, as quatro principais situações vivenciadas por usuários com deficiência são:</p>
               <p class="text-justify">•	Acesso ao computador sem mouse: no caso de pessoas com deficiência visual, dificuldade de controle dos movimentos, paralisia ou amputação de um membro superior;</p>
               <p class="text-justify">•	Acesso ao computador sem teclado: no caso de pessoas com amputações, grandes limitações de movimentos ou falta de força nos membros superiores;</p>
               <p class="text-justify">•	Acesso ao computador sem monitor: no caso de pessoas com cegueira;</p>
<p class="text-justify">•	Acesso ao computador sem áudio: no caso de pessoas com deficiência auditiva.
</p>

        
        
        <a href="http://emag.governoeletronico.gov.br/"><li>Saiba mais</li></a>
                      </div>
 <!--  fim do que aparece no desktop -->              
                      
<!--  aparece no mobile -->                    
        <div class="text-justify hidden-sm hidden-md hidden-lg">               <p class="text-justify">O computador e a Internet representam um enorme passo para a inclusão de pessoas com deficiência, promovendo autonomia e independência. Mas como pessoas com deficiência utilizam o computador?</p>
               <p class="text-justify">No que se refere a acesso ao computador, as quatro principais situações vivenciadas por usuários com deficiência...
          <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal"
          data-target="#myModal">Ver Mais...</a></div>
<!--  fim do que aparece no mobile --> 

          <div class="modal fade" id="myModal" tabindex="-1"
          role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span class="sr-only">Close</span>
                  </button>
                  <h4 class="modal-title titulo" id="myModalLabel">O acesso de pessoas com deficiência</h4>
                </div>
                <div class="modal-body">
                  
     <p class="text-justify">O computador e a Internet representam um enorme passo para a inclusão de pessoas com deficiência, promovendo autonomia e independência. Mas como pessoas com deficiência utilizam o computador?</p>
               <p class="text-justify">No que se refere a acesso ao computador, as quatro principais situações vivenciadas por usuários com deficiência são:</p>
               <p class="text-justify">•	Acesso ao computador sem mouse: no caso de pessoas com deficiência visual, dificuldade de controle dos movimentos, paralisia ou amputação de um membro superior;</p>
               <p class="text-justify">•	Acesso ao computador sem teclado: no caso de pessoas com amputações, grandes limitações de movimentos ou falta de força nos membros superiores;</p>
               <p class="text-justify">•	Acesso ao computador sem monitor: no caso de pessoas com cegueira;</p>
<p class="text-justify">•	Acesso ao computador sem áudio: no caso de pessoas com deficiência auditiva.
</p>

        <a href="http://www.cicacamp.com.br/Sao_Roque_Roteiro_do_Vinho.php"><li>Saiba mais</li></a>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div>          
          </div> 
</div>
    
    
    
    <div id="pvinho"class="divmargin">
        
        <h2 class="titulo">O processo para desenvolver um sítio acessível</h2>
        <p class="text-justify">A acessibilidade à Web refere-se a garantir acesso facilitado a qualquer pessoa, independente das condições físicas, dos meios técnicos ou dispositivos utilizados. No entanto, ela depende de vários fatores, tanto de desenvolvimento quanto de interação com o conteúdo. O processo para desenvolver um sítio acessível é realizado em três passos:</p>
       
</div>
    
    <div id="fases">
        <img src="imagens/emag-3-conferencia-web.jpg" class="img-responsive img-thumbnail imagemfloat" alt="uva">
        



                 <div id="fases">
                  <div title="modal" class="">
          <h2 class="titulo">Fases de Implementação</h2>
 <!--  aparece no desktop -->   
           <div class="hidden-xs">

       <p class="text-justify"><b>1º Passo:</b>Validar os códigos do conteúdo HTML e das folhas de estilo;.</p>
        
        <p class="text-justify"><b>2º Passo:</b>Verificar o fluxo de leitura da página. A forma mais simples é inibir o CSS, imagens e scripts, lendo apenas o HTML da página. Boa parte dos navegadores possuem ferramentas ou extensões que permitem essa visualização. Outra opção é utilizar navegadores textuais, como o Lynx ou um leitor de tela. Para maiores detalhes, ver documento Descrição dos Leitores de Tela, disponível em: http://www.governoeletronico.gov.br/acoes-e-projetos/eMAG/material-de-apoio..</p>

        <p class="text-justify"><b>3º Passo:</b>Realizar a validação automática de acessibilidade utilizando o ASES e outros avaliadores automáticos sugeridos no Capítulo 4, realizar a validação manual que é uma etapa essencial na avaliação de acessibilidade de um sítio, já que os validadores automáticos não são capazes de detectar todos os problemas de acessibilidade em um sítio, pois muitos aspectos requerem um julgamento humano. Por exemplo, validadores automáticos conseguem detectar se o atributo para descrever imagens foi utilizado em todas as imagens do sítio, mas somente uma pessoa poderá verificar se a descrição da imagem está adequada ao seu conteúdo.</p>
               
                      </div>
 <!--  fim do que aparece no desktop -->              
                      
<!--  aparece no mobile -->                    
        <div class="text-justify hidden-sm hidden-md hidden-lg">
            <b>1º Passo</b>1. Validar os códigos do conteúdo HTML e das folhas de estilo...
          <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal"
          data-target="#myModal2">Ver Mais...</a></div>
<!--  fim do que aparece no mobile --> 

          <div class="modal fade" id="myModal2" tabindex="-1"
          role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span class="sr-only">Close</span>
                  </button>
                  <h4 class="modal-title titulo" id="myModalLabel">Fases do Processo da Tradição</h4>
                </div>
                <div class="modal-body">
<img src="imagens/emag-3-conferencia-web.jpg" class="img-responsive img-thumbnail" alt="uva">
                           <p class="text-justify"><b>1º Passo:</b> Validar os códigos do conteúdo HTML e das folhas de estilo;.</p>
        
        <p class="text-justify"><b>2º Passo:</b> Verificar o fluxo de leitura da página. A forma mais simples é inibir o CSS, imagens e scripts, lendo apenas o HTML da página. Boa parte dos navegadores possuem ferramentas ou extensões que permitem essa visualização. Outra opção é utilizar navegadores textuais, como o Lynx ou um leitor de tela. Para maiores detalhes, ver documento Descrição dos Leitores de Tela, disponível em: http://www.governoeletronico.gov.br/acoes-e-projetos/eMAG/material-de-apoio.</p>

        <p class="text-justify"><b>3º Passo:</b>Realizar a validação automática de acessibilidade utilizando o ASES e outros avaliadores automáticos sugeridos no Capítulo 4, realizar a validação manual que é uma etapa essencial na avaliação de acessibilidade de um sítio, já que os validadores automáticos não são capazes de detectar todos os problemas de acessibilidade em um sítio, pois muitos aspectos requerem um julgamento humano. Por exemplo, validadores automáticos conseguem detectar se o atributo para descrever imagens foi utilizado em todas as imagens do sítio, mas somente uma pessoa poderá verificar se a descrição da imagem está adequada ao seu conteúdo.</p>


                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div>          
          </div>
        
        
        </div>
         <div class="col-xs-12 divmargin"><a href="#topo"><br><center>Voltar para o Topo</center></a></div> 
        </article>
        <!--Aqui começa o Footer-->
        <?php include "footer.php"; ?>
        <!--Aqui termina o Footer-->
    </body>
</div>

</html>