<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<div class="container">
    <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Acessibilidade</title>
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/estilo.css" rel="stylesheet" />
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>
    <!--Aqui começa o Header-->
    <?php include "header.php"; ?>
    <!--Aqui termina o Header-->

    <!--Aqui começa o Nav-->
    <?php include "nav.php"; ?>
    <!--Aqui termina o Nav-->

    <body data-spy="scroll" data-target=".teste">
        <br class="hidden-xs">
        <br class="hidden-xs">
        <article class="col-lg-12 col-xs-12 col-sm-12tab-content container">
            <div id="mata" class="divmargin">




                <!-- <div class="row" id="row-index">-->
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h2>A tecnologia Garante o acesso</h2>

                    <img src="imagens/logo_acessibilidade_web.jpg" alt="Simbolo de um caderante e de um computador, representando a acessibilidade na web para deficientes motores" class="col-lg-4 col-md-8 col-sm-12 col-xs-12" />

                    <p> Com o tempo a Internet se tornou algo indispensável na vida de muitas pessoas pessoas. Já pensou que esse meio pode ser um modo "Essencial" para as pessoas com deficiência. Há certas coisas que as pessoas com deficiência simplesmente não podem fazer por si próprios. </p>
                    <p> Mas, com o uso da internet elas podem atingir um grau elevado de independência. Elas podem ler uma notícia, realizar investigação em áreas de interesse, comprar mantimentos, e acessar o mundo - pelo menos potencialmente.</p>
                    <p> A maioria das tecnologias de assistência para pessoas com deficiência motora preferem usar o teclado para emular as funcionalidade do teclado comum. </p>
                    <p>Com isso a apresentação dos conteúdos sendo acessíveis atravéz do teclado, e assegurar que o site seja navegável com o uso de tão poucas teclas quanto possível. </p>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <table summary=" Tabela com os desafios e as suas soluções para que o site fique acessivel para pessoas com deficiencia motora" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <caption>Desafios e suas Soluções para um site acessivel</caption>
                        <thead>
                            <th>Desafios</th>
                            <th>Soluções</th>
                        </thead>

                        <tbody>
                            <tr>
                                <td>Usuário não pode fazer uso do mouse. </td>
                                <td>Certifique-se de que todas as funções estão disponíveis usando o teclado (tente tabular de link para link)</td>
                            </tr>

                            <tr>
                                <td>Usuário não pode controlar o uso do mouse ou teclado. </td>
                                <td>Certifique-se de que suas páginas são "tolerante a erros" (ex. pergunte "você tem certeza que deseja deletar este arquivo?") e não crie links pequenos ou que se movimentam.</td>
                            </tr>
                            <tr>
                                <td>Usuário pode estar fazendo uso de um Software de reconhecimento de Voz. </td>
                                <td>Softwares de ativação por voz podem replicar o movimento do mouse, mas não de maneira eficiente e funcional como fazemos no teclado, então tenha certeza de que todas as funções estão disponíveis para o teclado. </td>
                            </tr>
                            <tr>
                                <td>Os usuários podem ficar cansados quando se utiliza tecnologias de assistência semelhantes </td>
                                <td>Proporcionar um método para pular a longas listas de links ou outros conteúdos.</td>
                            </tr>



                        </tbody>


                    </table>
                </div>






                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <h2>Ferramentas</h2>
                    <p> Alguns dos tipos mais comuns de ajudas técnicas para as pessoas deficientes para a deficiência motora são encontradas abaixo. </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">

                    <h3>"Varinha de Cabeça"</h3>
                    <img src="imagens/ferramenta.jpg" alt="varinha de cabeça, acessorio que se prende a cabeça da pessoa" class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ferramentas" />


                    <p class="text-justify"> As “varinhas de cabeça” se prende o bastão na cabeça. A pessoa faz uso deslocando a cabeça para fazer a varinha escrever caracteres, navegar na web através de documentos e etc. </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h3>Teclados adaptados</h3>

                    <img src="imagens/teclado.jpg" alt="teclado adaptado para pessoas que não tem controle total dos movimentos musculares" class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ferramentas" />


                    <p class="text-justify"> Nos casos em que uma pessoa não tem controle confiável ou precisão dos movimentos na musculatura das mãos uma adaptação do teclado pode ser útil. Alguns teclados adaptáveis têm algumas áreas mais altas entre as teclas, a fim de permitir que primeiro a pessoa possa colocar a mão em baixo do teclado e, em seguida, deslizar o dedo para a tecla correta. </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h3>Rastreio dos olhos</h3>

                    <img src="imagens/rastreio.jpg" alt="equipamento que é utlizado para o uso do computador com os olhos. Pars pessoas sem nenhuma mobilidade" class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ferramentas" />


                    <p class="text-justify"> Nos casos em que uma pessoa não tem controle confiável ou precisão dos movimentos na musculatura das mãos uma adaptação do teclado pode ser útil. Alguns teclados adaptáveis têm algumas áreas mais altas entre as teclas, a fim de permitir que primeiro a pessoa possa colocar a mão em baixo do teclado e, em seguida, deslizar o dedo para a tecla correta. </p>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <h3>Software para reconhecimento de voz</h3>




                    <p class="text-justify"> Nos casos em que uma pessoa não tem controle confiável ou precisão dos movimentos na musculatura das mãos uma adaptação do teclado pode ser útil. Alguns teclados adaptáveis têm algumas áreas mais altas entre as teclas, a fim de permitir que primeiro a pessoa possa colocar a mão em baixo do teclado e, em seguida, deslizar o dedo para a tecla correta. </p>
                </div>
                <!--</div>-->
            </div>

            <div class="col-xs-12 divmargin">
                <a href="#topo">
                    <br>
                    <center>Voltar para o Topo</center>
                </a>
            </div>
        </article>
        <!--Aqui começa o Footer-->
        <?php include "footer.php"; ?>
        <!--Aqui termina o Footer-->
    </body>
</div>

</html>