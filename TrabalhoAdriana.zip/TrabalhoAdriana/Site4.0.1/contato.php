<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
    <div class="container"> <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acessibilidade</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<!--Aqui começa o Header-->
    <?php
    include"header.php";
    ?>
<!--Aqui termina o Header-->
    
<!--Aqui começa o Nav-->
    <?php
    include"nav.php";    
    ?>
<!--Aqui termina o Nav-->
<body data-spy="scroll" data-target=".teste">
    <br class="hidden-xs">
    <br class="hidden-xs">
    <article class="col-lg-12 col-xs-12 col-sm-12tab-content container">
         <div class="row">

  <div class="col-md-6">

<center>
  <img src="imagens/braille.jpg" class="img-responsive img-rounded" alt="cego lendo em braile" class="img-rounded">
</center>

        <div id="mata" class="divmargin">

        </div>

            <div class="hidden-xs">
                <h2 class="titulo">Acessibilidade visual</h2>
                <p class="text-justify">Obviamente, as pessoas cegas não são capazes de enxergar as coisas da mesma maneira dos que não são cegos. Ainda mesmo que seja verdade que a maior parte das pessoas cegas têm algum grau de visão, para todos os efeitos, pode-se dizer que as pessoas cegas não usam seus olhos para acessar a web, porque o que eles têm de visão útil não é suficiente para este tipo da tarefa. Isto significa que um monitor de computador e mouse não seria algo muito útil para uma pessoa cega. Não que as pessoas cegas são incapazes de mover um mouse ou clicar; o fato é que eles não sabem para onde deslocar o mouse ou quando clicar, uma vez que não podem ver o que está na tela.Então, basta ver o modo como as pessoas cegas usam a internet?</p>
                <p class="text-justify"></p>
                 <p class="text-justify"><p>
            </div>

            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <h2 class="titulo">Acessibilidade visual</h2>
                <p class="text-justify">Obviamente, as pessoas cegas não são capazes de enxergar as coisas da mesma maneira dos que não são cegos.</p>
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal">Ver Mais...</a>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Fechar</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Acessibilidade visual</h4>
                                </div>
                                <div class="modal-body">

                                    <p class="text-justify">Obviamente, as pessoas cegas não são capazes de enxergar as coisas da mesma maneira dos que não são cegos. Ainda mesmo que seja verdade que a maior parte das pessoas cegas têm algum grau de visão, para todos os efeitos, pode-se dizer que as pessoas cegas não usam seus olhos para acessar a web, porque o que eles têm de visão útil não é suficiente para este tipo da tarefa. Isto significa que um monitor de computador e mouse não seria algo muito útil para uma pessoa cega. Não que as pessoas cegas são incapazes de mover um mouse ou clicar; o fato é que eles não sabem para onde deslocar o mouse ou quando clicar, uma vez que não podem ver o que está na tela.Então, basta ver o modo como as pessoas cegas usam a internet?</p>
 
                                    

                                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>


        


       <div class="col-md-6">

        <center>

        <img src="imagens/cromevox.jpg" class="img-responsive img-rounded" alt="leitor cromevox" class="img-thumbnail">
       </center>
      
<div id="estacao" class="divmargin">
            <div class="hidden-xs">
                <h2 class="titulo">Leitores de tela</h2>
                <p class="text-justify">O leitor de tela é um software usado para obter resposta do computador por meio sonoro, usado principalmente por deficientes visuais.Também pode ser usado apenas para uma maior eficiência e conforto do usuário. As pessoas portadoras de deficiência visual podem navegar pela Internet, bem como por aplicações em geral, utilizando um programa de leitura de tela. Estes programas vão passando por textos e imagens e sintetizando a fala humana. Basicamente, o programa lê para o usuário o que aparece na tela, tal como </p>
                <p class="text-justify">as operações realizadas, como teclas alfanuméricas e comandos digitados. Entre os programas disponíveis para deficientes visuais estão:  </p>
                <p class="text-justify"></p>
                <p class="text-justify"></p>
            </div>
            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <h2 class="titulo">Leitores de tela</h2>
                <p class="text-justify">O leitor de tela é um software usado para obter resposta do computador por meio sonoro, usado principalmente por deficientes visuais.</p>
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal2">Ver Mais...</a>
                    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Leitores de tela</h4>
                                </div>
                                <div class="modal-body">
                                    <p class="text-justify">O leitor de tela é um software usado para obter resposta do computador por meio sonoro, usado principalmente por deficientes visuais.Também pode ser usado apenas para uma maior eficiência e conforto do usuário. As pessoas portadoras de deficiência visual podem navegar pela Internet, bem como por aplicações em geral, utilizando um programa de leitura de tela. Estes programas vão passando por textos e imagens e sintetizando a fala humana. Basicamente, o programa lê para o usuário o que aparece na tela, tal como

as operações realizadas, como teclas alfanuméricas e comandos digitados. Entre os programas disponíveis para deficientes visuais estão:</p>
                                    <p class="text-justify"></p>
                                    <p class="text-justify"></p>

   
                                     
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>

        
        </div>

        </div>
       <!--fim da row!-->


        <div class="row">

  <div class="col-md-6">

 <center>
  <img src="imagens/jaws.jpg" class="img-responsive img-rounded" alt="imagem leitor jaws" class="img-thumbnail">
 </center>

        <div  class="divmargin">

            

            



  
</div>

            <div class="hidden-xs">
                <h2 class="titulo">Limitaçoes dos leitores de tela</h2>
                <p class="text-justify">Leitores de tela são equipamentos bastante robustos em suas capacidades, mas têm limitações. Eles não podem substituir totalmente uma experiência visual. Felizmente, existem formas de compensar as deficiências dos Leitores de Tela.</p>
                <p class="text-justify"><h3>Imagens</h3> Os Leitores de tela não podem descrever imagens. A única maneira que um leitor de tela tem para poder transmitir o significado de uma imagem é a leitura do texto do documento que serve como um substituto ou alternativo para a  imagem. Se não houver um texto alternativo, etiqueta "alt" com o texto, então o leitor de tela não podem transmitir textualmente o significado de uma imagem.</p>
                 <p class="text-justify"><h3>Visual e layout</h3> Além disso, leitores de tela não podem fazer o levantamento da totalidade de uma página da web como um usuário visual pode fazer. Um usuário visual pode olhar para uma página da web e logo perceber a forma como a página está organizada, para em seguida ir para o conteúdo mais importante. Um leitor de tela não é capaz de fazer isso. Ele lê de forma linear, uma palavra de cada vez. Não pode sempre saltar de maneira mais inteligente alheio aos  conteúdos intermediário, tais como anúncios ou barras de navegação.</p>
                  <p class="text-justify"><h3>Tabelas de Dados</h3> Do mesmo modo, devido aos Leitores de tela terem de realizar a leitura linearmente os dados de tabelas podem ficar bastante confuso. Imagine ao tentar ouvir o conteúdo de um grande quadro de dados com 14 colunas e 28 linhas. Até que o usuário tenha lido a linha 20 já terá tido tempo de esquecer o título da coluna 8. Pode ser difícil, se não impossível tentar interpretar essas informações.</p>
            </div>

            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <h2 class="titulo">Limitaçoes dos leitores de tela</h2>
                <p class="text-justify">Leitores de tela são equipamentos bastante robustos em suas capacidades, mas têm limitações. Eles não podem substituir totalmente uma experiência visual.</p>
                    <a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal">Ver Mais...</a>
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Limitaçoes dos leitores de tela</h4>
                                </div>
                                <div class="modal-body">
 
                                   <p class="text-justify">Leitores de tela são equipamentos bastante robustos em suas capacidades, mas têm limitações. Eles não podem substituir totalmente uma experiência visual. Felizmente, existem formas de compensar as deficiências dos Leitores de Tela.</p>
                                    <p class="text-justify"><h3>Imagens</h3> Os Leitores de tela não podem descrever imagens. A única maneira que um leitor de tela tem para poder transmitir o significado de uma imagem é a leitura do texto do documento que serve como um substituto ou alternativo para a  imagem. Se não houver um texto alternativo, etiqueta "alt" com o texto, então o leitor de tela não podem transmitir textualmente o significado de uma imagem.</p>
                 <p class="text-justify"><h3>Visual e layout</h3> Além disso, leitores de tela não podem fazer o levantamento da totalidade de uma página da web como um usuário visual pode fazer. Um usuário visual pode olhar para uma página da web e logo perceber a forma como a página está organizada, para em seguida ir para o conteúdo mais importante. Um leitor de tela não é capaz de fazer isso. Ele lê de forma linear, uma palavra de cada vez. Não pode sempre saltar de maneira mais inteligente alheio aos  conteúdos intermediário, tais como anúncios ou barras de navegação.</p>
                  <p class="text-justify"><h3>Tabelas de Dados</h3> Do mesmo modo, devido aos Leitores de tela terem de realizar a leitura linearmente os dados de tabelas podem ficar bastante confuso. Imagine ao tentar ouvir o conteúdo de um grande quadro de dados com 14 colunas e 28 linhas. Até que o usuário tenha lido a linha 20 já terá tido tempo de esquecer o título da coluna 8. Pode ser difícil, se não impossível tentar interpretar essas informações.</p>
  
                                      
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>


        


       <div class="col-md-6">

         <center>

        <img src="imagens/nvda.jpg" class="img-responsive img-rounded" alt="imagem leitor nvda" >
          </center>
      



        <div  class="divmargin">

             

            <div class="hidden-xs">
                <h2 class="titulo">Como funcionam os leitores de tela</h2>
                <p class="text-justify">O leitor de tela é um software utilizado principalmente por pessoas cegas, que fornece informações através de síntese de voz sobre os elementos exibidos na tela do computador. Esses softwares interagem com o sistema operacional, capturando as informações apresentadas na forma de texto e transformando-as em resposta falada através de um sintetizador de voz. Para navegar utilizando um leitor de tela, o usuário faz uso de comandos pelo teclado. O leitor de tela também pode transformar o conteúdo em informação tátil, exibida dinamicamente em Braille por um hardware chamado de linha ou display Braille, servindo, em especial, a usuários com surdocegueira. Pessoas com baixa visão e pessoas com dislexia também podem fazer uso dos leitores de tela.</p>
                 <p class="text-justify">A navegação na Web funciona, basicamente, de três maneiras:</p>
                                    <p class="text-justify">Lendo toda a página (navegação com as setas) </p>
                                    <p class="text-justify">Lendo os links (navegação com a tecla Tab) </p>
                                    <p class="text-justify">Lendo os cabeçalhos (navegação com a tecla h) </p>
                        </div>


            <div title="modal" class="hidden-sm hidden-md hidden-lg">
                <h2 class="titulo">Como funcionam os leitores de tela</h2>
                <p class="text-justify"> O leitor de tela é um software utilizado principalmente por pessoas cegas<a type="button" teste="btn btn-primary btn-lg buttonteste" data-toggle="modal" data-target="#myModal2">Ver Mais...</a>
                    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">×</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title titulo" id="myModalLabel">Como funcionam os leitores de tela</h4>
                                </div>
                                <div class="modal-body">

                                    <p class="text-justify">O leitor de tela é um software utilizado principalmente por pessoas cegas, que fornece informações através de síntese de voz sobre os elementos exibidos na tela do computador. Esses softwares interagem com o sistema operacional, capturando as informações apresentadas</p>
                                    <p class="text-justify">A navegação na Web funciona, basicamente, de três maneiras:</p>
                                    <p class="text-justify">Lendo toda a página (navegação com as setas) </p>
                                    <p class="text-justify">Lendo os links (navegação com a tecla Tab) </p>
                                    <p class="text-justify">Lendo os cabeçalhos (navegação com a tecla h) </p>
                                    <p class="text-justify"></p>

                                    

                                                                            <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>

        
        </div>

        </div>
       <!--fim da row!-->


















        <div class="col-xs-12 divmargin">
            <a href="#topo">
                <br>
                <center>Voltar para o Topo</center>
            </a>
        </div>
    </article>
    <!--Aqui começa o Footer-->
        <?php
        include"footer.php";
        ?>
    <!--Aqui termina o Footer-->
</body>
    </div>
</html>