<!DOCTYPE html>
<html dir="ltr" lang="pt-BR">
<div class="container">
    <!-- Essa DIV irá fechar só no final da página acima do fechamento do html !-->

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Acessibilidade</title>
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/estilo.css" rel="stylesheet" />
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>

    <!--Aqui começa o Header-->
    <?php include( "header.php"); ?>
    <!--Aqui termina o Header-->

    <!--Aqui começa o Nav-->
    <?php include( "nav.php"); ?>
    <!--Aqui termina o Nav-->

<body data-spy="scroll" data-target=".teste">
    <br class="hidden-xs">
    <br class="hidden-xs">
    
    <article class="col-lg-6 col-md-6 col-xs-12  col-sm-12tab-content container">
            
        <div id="mata" class="divmargin">

    
                <h2 class="titulo">Técnicas de memorização</h2>                
            
                <p class="text-justify">Em informática, programas que tornam o conteúdo mais acessível são ferramentas ou um conjunto delas que permitem que portadores de deficiências se utilizem dos recursos que o computador oferece. Essas ferramentas são diversas e entre elas estão os leitores de ecrã (leitores de tela) como o JAWS e o Dosvox, para deficientes visuais, teclados virtuais para portadores de deficiência motora ou com dificuldades de coordenação motora, e sintetizadores de voz para pessoas com problemas de fala.

                    Na Internet o termo acessibilidade refere-se também a recomendações do W3C, que visam permitir que todos possam ter acesso aos websites, independente de terem alguma deficiência ou não. As recomendações abordam desde o tipo de fonte a ser usado, assim como seu tamanho e cor, de acordo com as necessidades do usuário, até a recomendações relativas ao código (HTML e CSS, por exemplo). isso ajuda aos usuários uma melhoria na informação, podendo assim garantir que a internet chegue a todos de forma simples e precisa. A acessibilidade tem que ser expandida para vários campos da sociedade garantindo que pessoas deficientes tenham acesso a várias formas de serviços, melhorando sua qualidade de vida e integrando-as a sociedade. </p>
            </div>
            
  
        
    </article>
            <aside class="col-lg-6 col-md-6 col-xs-12 col-sm-12tab-content container">
            
                 <img src="imagens/acessibilidadeum.jpg" class="" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                    
            
            </aside>
    
            <div class="col-lg-7 col-md-6 col-xs-12  col-sm-12tab-content container"></div>
            
            <div class="col-lg-6 col-md-6 col-xs-12  col-sm-12tab-content container">
                
                    
                          
         
        <h2 class="titulo">Assassinando a língua portuguesa</h2>                
            
                <p class="text-justify">Em informática, programas que tornam o conteúdo mais acessível são ferramentas ou um conjunto delas que permitem que portadores de deficiências se utilizem dos recursos que o computador oferece. Essas ferramentas são diversas e entre elas estão os leitores de ecrã (leitores de tela) como o JAWS e o Dosvox, para deficientes visuais, teclados virtuais para portadores de deficiência motora ou com dificuldades de coordenação motora, e sintetizadores de voz para pessoas com problemas de fala.

                    Na Internet o termo acessibilidade refere-se também a recomendações do W3C, que visam permitir que todos possam ter acesso aos websites, independente de terem alguma deficiência ou não. As recomendações abordam desde o tipo de fonte a ser usado, assim como seu tamanho e cor, de acordo com as necessidades do usuário, até a recomendações relativas ao código (HTML e CSS, por exemplo). isso ajuda aos usuários uma melhoria na informação, podendo assim garantir que a internet chegue a todos de forma simples e precisa. A acessibilidade tem que ser expandida para vários campos da sociedade garantindo que pessoas deficientes tenham acesso a várias formas de serviços, melhorando sua qualidade de vida e integrando-as a sociedade. </p>
                </div>
    <aside class="col-lg-6 col-md-6 col-xs-12 col-sm-12tab-content container">
            
                 <img src="imagens/acessibilidadeum.jpg" class="" alt="Imagem de um globo terrestre que foi construído com vários quadrados e em cada um deles é mostrada uma imagem  com pessoas que possuem algum tipo de deficiência"/>
                    
            
            </aside>
            
    
    <div id="estacao" class="divmargin">           
            
        <div class="col-xs-12 divmargin">
            <a href="#topo">
                <br>
                <center>Voltar para o Topo</center>
            </a>
        </div>
            
            
            
    <!--Aqui começa o Footer-->
        <?php
        include("footer.php");
        ?>
    <!--Aqui termina o Footer-->
</body>
</div>

</html>