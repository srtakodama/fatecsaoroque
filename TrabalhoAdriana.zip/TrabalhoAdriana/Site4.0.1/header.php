<header>
    <img class='center-block hidden-xs img-responsive' src='imagens/banner.jpg' alt="Imagem do Cabeçalho com varios símbolos, como deficiente auditivo, cadeirante e deficiencia motora">
    <img class='center-block hidden-lg hidden-md hidden-sm img-responsive'  src='imagens/header-pequeno.jpg'>
</header>


